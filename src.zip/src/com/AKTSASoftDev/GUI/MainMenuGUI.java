package com.AKTSASoftDev.GUI;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.io.IOException;

import static com.AKTSASoftDev.GUI.SudokuGUI.loadSudokuGUI;
import static com.AKTSASoftDev.GUI.WordSearchGUI.loadWordSearchGUI;

public class MainMenuGUI {

    public static Stage loadMainMenu() throws IOException{
        Stage primaryStage = new Stage();
        VBox root = new VBox(40);
        root.setAlignment(Pos.CENTER);
        Text title = new Text("Logic Puzzles");
        title.setFont(Font.font("Tahoma", 28));
        root.getChildren().add(title);
        Text puzzleText = new Text("Select Your Puzzle: ");
        puzzleText.setFont(Font.font("Tahoma", 16));
        puzzleText.setTextAlignment(TextAlignment.LEFT);
        root.getChildren().add(puzzleText);
        HBox puzzleButtons = new HBox(20);
        puzzleButtons.setAlignment(Pos.CENTER);
        Button wordSearchButton = new Button("Word Search");
        wordSearchButton.setOnAction(event -> {
            Stage wordSearchStage = loadWordSearchGUI();
            wordSearchStage.show();
        });
        wordSearchButton.setPrefSize(100, 50);
        Button sudokuButton = new Button("Sudoku");
        sudokuButton.setOnAction(event -> {
            Stage sudokuStage = loadSudokuGUI();
            sudokuStage.show();
        });
        sudokuButton.setPrefSize(100, 50);
//        Button anagramButton = new Button("Anagrams");
//        anagramButton.setOnAction(event -> {
//            Stage sudokuStage = loadSudokuGUI();
//            sudokuStage.show();
//        });
        puzzleButtons.getChildren().addAll(wordSearchButton, sudokuButton /*, anagramButton */);
        root.getChildren().add(puzzleButtons);
//        Image akLogo = new Image("com/AKTSASoftDev/GUI/assets/AKlogo.png");
//        ImageView logoView = new ImageView(akLogo);
//        logoView.setFitWidth(100);
//        logoView.setFitHeight(100);
//        root.getChildren().add(logoView);
        Scene scene = new Scene(root, 400, 200);
        scene.getStylesheets().add("com/AKTSASoftDev/GUI/assets/mainmenu.css");
        primaryStage.setTitle("Logic Puzzles");
        primaryStage.setScene(scene);
//        primaryStage.getIcons().add(akLogo);
        return primaryStage;
    }
}
