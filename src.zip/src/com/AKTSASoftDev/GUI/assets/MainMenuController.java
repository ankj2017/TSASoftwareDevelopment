package com.AKTSASoftDev.GUI.assets;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.stage.Stage;

import java.io.IOException;

import static com.AKTSASoftDev.GUI.SudokuGUI.loadSudokuGUI;
import static com.AKTSASoftDev.GUI.WordSearchGUI.loadWordSearchGUI;

public class MainMenuController {
    @FXML
    void loadSudoku(ActionEvent event) throws IOException{
        Stage sudokuStage = loadSudokuGUI();
        sudokuStage.show();
    }

    @FXML
    void loadWordSearch(ActionEvent event) {
        Stage wordSearchStage = loadWordSearchGUI();
        wordSearchStage.show();
    }
}
