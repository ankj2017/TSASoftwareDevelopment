package com.AKTSASoftDev.GUI;

import com.AKTSASoftDev.puzzles.sudoku.Cell;
import com.AKTSASoftDev.puzzles.sudoku.Sudoku;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class SudokuGUI {

    public static BackgroundFill redFill = new BackgroundFill(Paint.valueOf("#FF2222"), CornerRadii.EMPTY, Insets.EMPTY);
    public static BackgroundFill greenFill = new BackgroundFill(Paint.valueOf("#22FF22"), CornerRadii.EMPTY, Insets.EMPTY);
    public static int currButton = -1;
    public static int[][] grid;
    public static Cell[][] puzzle = new Cell[9][9];
    public static GridPane gridPane;
    static int numCorrect = 0;
    static Stage stage;
    static Sudoku sudoku;
    static boolean checked = false;

    public static Stage loadSudokuGUI() {
        stage = new Stage();
        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        sudoku = new Sudoku();
        int[][] grid = sudoku.getBoard();
        Text title = new Text("Sudoku");
        title.setTextAlignment(TextAlignment.CENTER);
        title.setFont(Font.font("Tahoma", 28));
        gridPane = new GridPane();
        gridPane.setVgap(5);
        gridPane.setHgap(5);
        gridPane.setAlignment(Pos.CENTER);
        for(int i = 0; i < 9; i++){
            for(int j = 0; j < 9; j++){
                Cell cell = new Cell(i, j, grid[i+1][j+1]);
                puzzle[i][j] = cell;
                gridPane.add(cell, i, j);
            }
        }
        HBox checkBar = new HBox(50);
        Button check = new Button("Check");
        check.setOnAction(event -> checkPuzzle());
        Button reset = new Button("Reset");
        reset.setOnAction(event -> reset());
        Button next = new Button("Next");
        next.setOnAction(event -> restart());
        checkBar.getChildren().addAll(check, reset, next);
        checkBar.setAlignment(Pos.CENTER);
        HBox buttonBar = new HBox(10);
        buttonBar.setAlignment(Pos.BASELINE_CENTER);
        Button b1 = new Button("1");
        b1.setOnAction(event -> currButton = 0);
        Button b2 = new Button("2");
        b2.setOnAction(event -> currButton = 1);
        Button b3 = new Button("3");
        b3.setOnAction(event -> currButton = 2);
        Button b4 = new Button("4");
        b4.setOnAction(event -> currButton = 3);
        Button b5 = new Button("5");
        b5.setOnAction(event -> currButton = 4);
        Button b6 = new Button("6");
        b6.setOnAction(event -> currButton = 5);
        Button b7 = new Button("7");
        b7.setOnAction(event -> currButton = 6);
        Button b8 = new Button("8");
        b8.setOnAction(event -> currButton = 7);
        Button b9 = new Button("9");
        b9.setOnAction(event -> currButton = 8);
        buttonBar.getChildren().addAll(b1, b2, b3, b4, b5, b6, b7, b8, b9);
        root.getChildren().addAll(title, gridPane, checkBar, buttonBar);
        Scene scene = new Scene(root, 600, 600);
        stage.setTitle("Sudoku");
        stage.setScene(scene);
        return stage;
    }

    public static void checkPuzzle() {
        if(checked){
            for (Cell[] row : puzzle) {
                for (Cell c : row) {
                    c.setFill(c.getFill());
                }
            }
            checked = false;
        }
        else {
            for(int i = 0; i < 9; i++){
                for(int j = 0; j < 9; j++) {
                    Cell cell = puzzle[i][j];
                    boolean correct = true;
                    for (int x = i + 1; x < 9; x++) {
                        if (puzzle[x][j].userValue == cell.userValue) {
                            correct = false;
                        }
                    }
                    for (int y = j + 1; y < 9; y++) {
                        if (puzzle[i][y].userValue == cell.userValue) {
                            correct = false;
                        }
                    }
                    if(cell.userValue == -1){
                        correct = false;
                    }
                    if (correct) {
                        cell.setFill(greenFill);
                        numCorrect++;
                    } else {
                        cell.setFill(redFill);
                    }
                }
                checked = true;
        }
    }
//        Thread thread = new Thread() {
//            public void run() {
//                try{Thread.sleep(3000);} catch(InterruptedException exc) {}
//            }
//        };
//        thread.start();
//        if(numCorrect == 81){
//            numCorrect = 0;
//            restart();
//        }
//        else {
//        for (Cell[] row : puzzle) {
//            for (Cell c : row) {
//                c.setFill(c.fill);
//            }
//        }
    }

    public static void reset(){
        for(Cell[] row : puzzle){
            for(Cell c: row){
                if(!c.show){
                    c.userValue = -1;
                    c.setText("");
                }
            }
        }
        checked = false;
    }

    public static void restart(){
        sudoku = new Sudoku();
        grid = sudoku.getBoard();
        for(int i = 0; i < 9; i++){
            for(int j = 0; j < 9; j++){
                puzzle[i][j] = new Cell(i, j, grid[i+1][j+1]);
                gridPane.add(puzzle[i][j], i, j);
            }
        }
        checked = false;
    }
}
