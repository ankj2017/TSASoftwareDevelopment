package com.AKTSASoftDev.puzzles.sudoku;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Text;

import static com.AKTSASoftDev.GUI.SudokuGUI.currButton;

public class Cell extends StackPane {

    static final BackgroundFill TOP_LEFT = new BackgroundFill(Paint.valueOf("#C9FFE5"), CornerRadii.EMPTY, Insets.EMPTY);
    static final BackgroundFill TOP_CENTER = new BackgroundFill(Paint.valueOf("#9966CC"), CornerRadii.EMPTY, Insets.EMPTY);
    static final BackgroundFill TOP_RIGHT = new BackgroundFill(Paint.valueOf("#FF9966"), CornerRadii.EMPTY, Insets.EMPTY);
    static final BackgroundFill CENTER_LEFT = new BackgroundFill(Paint.valueOf("#BCD4E6"), CornerRadii.EMPTY, Insets.EMPTY);
    static final BackgroundFill CENTER_CENTER = new BackgroundFill(Paint.valueOf("#FFC1CC"), CornerRadii.EMPTY, Insets.EMPTY);
    static final BackgroundFill CENTER_RIGHT = new BackgroundFill(Paint.valueOf("#DE5D83"), CornerRadii.EMPTY, Insets.EMPTY);
    static final BackgroundFill BOTTOM_LEFT = new BackgroundFill(Paint.valueOf("#3399FF"), CornerRadii.EMPTY, Insets.EMPTY);
    static final BackgroundFill BOTTOM_CENTER = new BackgroundFill(Paint.valueOf("#E97451"), CornerRadii.EMPTY, Insets.EMPTY);
    static final BackgroundFill BOTTOM_RIGHT = new BackgroundFill(Paint.valueOf("#DFFF00"), CornerRadii.EMPTY, Insets.EMPTY);
    private static BackgroundFill transparentFill = new BackgroundFill(Color.hsb(270, 1.0, 1.0, 0), CornerRadii.EMPTY, Insets.EMPTY);
    static final BackgroundFill[] FILLS = {TOP_LEFT, CENTER_LEFT, BOTTOM_LEFT, TOP_CENTER, CENTER_CENTER, BOTTOM_CENTER, TOP_RIGHT, CENTER_RIGHT, BOTTOM_RIGHT};
    BackgroundFill fill;
    private int value;
    public int i, j;
    public boolean show = false;
    private static final int numShow = 40;
    private static final double showProb = numShow/81.0;
    private TextField in;
    private Text text;
    public int userValue = -1;

    public Cell(int i, int j, int val){
        super();
        this.i = i;
        this.j = j;
        this.fill = FILLS[computeBoxNumber(i, j)];
        this.setBackground(new Background(this.fill));
        this.value = val;
        in = new TextField();
        in.setAlignment(Pos.CENTER);
        in.setPrefWidth(20);
        in.setPrefHeight(20);
        in.setEditable(false);
        in.setOnMouseClicked(event -> process());
        in.setBackground(new Background(transparentFill));
        text = new Text();
        if(Math.random() < showProb){
            show = true;
        }
        if(show){
            text.setText(String.valueOf(value));
            userValue = value;
        }
        this.getChildren().addAll(in, text);
    }

    private void process(){
        if(currButton != -1 && !show){
            int val = currButton + 1;
            text.setText(String.valueOf(val));
            userValue = val;
            currButton = -1;
        }
    }

    public static int computeBoxNumber(int i, int j){
        int d1, d2;
        if(i < 3){
            d1 = 0;
        }
        else if(i < 6){
            d1 = 1;
        }
        else {
            d1 = 2;
        }
        if(j < 3){
            d2 = 0;
        }
        else if(j < 6){
            d2 = 1;
        }
        else {
            d2 = 2;
        }
        return (3*d1 + d2);
    }

    public int getValue(){
        return value;
    }

    public void setValue(int value){
        this.value = value;
    }

    public void setText(String value){
        this.text.setText(value);
    }

    public BackgroundFill getFill() {
        return this.fill;
    }

    public void setFill(BackgroundFill fill){
        this.setBackground(new Background(fill));
    }
}