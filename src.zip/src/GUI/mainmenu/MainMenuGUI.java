package GUI.mainmenu;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import static puzzles.wordsearch.WordSearchGUI.loadWordSearch;

public class MainMenuGUI {

    public static Stage loadMainMenu(){

        Stage primaryStage = new Stage();
        VBox root = new VBox(40);
        root.setAlignment(Pos.CENTER);
        Text title = new Text("Logix Puzzles");
        title.setFont(Font.font("Tahoma", 28));
        root.getChildren().add(title);
        Text puzzleText = new Text("Select Your Puzzle: ");
        puzzleText.setFont(Font.font("Tahoma", 16));
        puzzleText.setTextAlignment(TextAlignment.LEFT);
        root.getChildren().add(puzzleText);
        HBox puzzleButtons = new HBox(20);
        puzzleButtons.setAlignment(Pos.CENTER);
        Button wordSearchButton = new Button("Word Search");
        wordSearchButton.setOnAction(event -> {
            Stage wordSearchStage = loadWordSearch();
            wordSearchStage.show();
        });
        Button sudokuButton = new Button("Sudoku");
        Button anagramButton = new Button("Anagrams");
        puzzleButtons.getChildren().addAll(wordSearchButton, sudokuButton, anagramButton);
        root.getChildren().add(puzzleButtons);
        Scene scene = new Scene(root, 600, 600);
        scene.getStylesheets().add("assets/mainmenu.css");
        primaryStage.setTitle("Word Search");
        primaryStage.setScene(scene);

        return primaryStage;
    }
}
